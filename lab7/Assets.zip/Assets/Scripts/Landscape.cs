﻿using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace CGCV1920.LandscapeGeneration.Scripts
{
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public class Landscape : MonoBehaviour
    {
        private bool _isDirty;
        private Mesh _mesh;
        [SerializeField] private Gradient gradient;

        [Range(0, 1)] [SerializeField] private float gain = 0.5f;
        [Range(1, 3)] [SerializeField] private float lacunarity = 2f;
        [Range(1, 8)] [SerializeField] private int octaves = 4;

        [SerializeField] private float scale = 5f;
        [SerializeField] private Vector2 shift = Vector2.zero;
        [SerializeField] private int state = 0;
        [SerializeField] private int resolution = 256;
        [SerializeField] private float length = 256f;
        [SerializeField] private float height = 50f;
        Vector3[] vertices;

        private void Awake()
        {
            (GetComponent<MeshFilter>().mesh = _mesh = new Mesh { name = name }).MarkDynamic();
        }

        private void OnValidate()

        {
            //print("in validate");
            //print(_isDirty);
            _isDirty = true;
        }
        private void Update()
        {
            //print("in update");
           // print(_isDirty);
            if (!_isDirty) return;
         
            GenerateLandscape();
            _isDirty = false;
        }

        private void GenerateLandscape()
        {
            // First, initialize the data structures:
            var colors = new Color[(resolution + 1) * (resolution + 1)];
            vertices = new Vector3[(resolution+1)*(resolution + 1) ];
            var triangles = new int[(resolution*resolution*6)];

  

            // Then, loop over the vertices and populate the data structures:
            for (int i = 0, z = 0; z<= resolution; z++)
            {
                for (int x = 0; x<= resolution; x++)
                {
                    Vector2 coords = new Vector2((float)x / (resolution - 1), (float)z / (resolution - 1));
                    var elevation = 1.414214f * FractalNoise(coords, gain, lacunarity, octaves, scale, shift, state);
                    colors[i]   = gradient.Evaluate(elevation /2);
                    vertices[i] = new Vector3(length * coords.x, height * elevation, length * coords.y);
                    i++;
                }
            }

            int step = 0;
            int verti = 0;
            for (int z = 0; z < resolution; z++)
            {

                for (int x = 0; x < resolution; x++)
                {
                    triangles[0 + step] = verti;
                    triangles[1 + step] = verti + resolution + 1;
                    triangles[2 + step] = verti + 1;
                    triangles[3 + step] = verti + 1;
                    triangles[4 + step] = verti + resolution + 1;
                    triangles[5 + step] = verti + resolution + 2;

                    verti++;
                    step += 6;
                }
                verti++;
            }



            // Assign the data structures to the mesh
           
            _mesh.Clear();
             _mesh.SetVertices(vertices);
             _mesh.SetColors(colors);
             _mesh.SetTriangles(triangles, 0);
             _mesh.RecalculateNormals();
        }

        private static float FractalNoise(Vector2 coords, float gain, float lacunarity, int octaves, float scale,
            Vector2 shift, int state)
        {
            Random.InitState(state);

            float frequency = 1;
            float amplitude = 1;
            float noiseHeight = 0;

            for (int i = 0; i < octaves; i++)
            {
                float random = Random.value;
                float x = coords.x * frequency * scale + random + shift.x;
                float y = coords.y * frequency * scale + random + shift.y;
                float perlinValue = Mathf.PerlinNoise(x, y);
                noiseHeight += perlinValue * amplitude;
                amplitude *= gain;
                frequency *= lacunarity;
            }
            return noiseHeight;

            throw new NotImplementedException();
        }

        public void AdjustGain(float newGain)
        {
            print("gain");
            print(_isDirty);
            print(gain);
            gain = newGain;
            Update();
            print("update");
            _isDirty = true;
            print(_isDirty);
        }

        public void AdjustOctaves(float newOctaves) {
            octaves = Convert.ToInt32(newOctaves);
            Update();
            _isDirty = true;
        }

        public void AdjustLacunarity(float newLacunarity)
        {
            lacunarity = newLacunarity;
            Update();
            _isDirty = true;
        }


        private void OnDrawGizmos()
        {
            if (vertices == null) return;

            for(int i =0; i<vertices.Length; i++)
            {
                Gizmos.DrawSphere(vertices[i], .1f); 
            }
        }
    }
}